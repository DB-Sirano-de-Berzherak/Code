GPS/GLONASS (Troyka-модуль)
===========================

Библиотека для Arduino, позволяющая считывать данные с GPS/GLONASS модулей:
* [GPS/GLONASS модуль со встроенной антенной.](http://amperka.ru/product/troyka-gps-glonass)
* [GPS/GLONASS модуль с выносной антенной.](http://amperka.ru/product/troyka-gps-glonass-extended-reciver)

Установка библиотеки
====================

В Arduino IDE выберите пункт меню «Скетч» → «Импортировать библиотеку» →
«Добавить библиотеку…». В появившемся окне выберите скачаный архив с
библиотекой. Установка завершена.

Подробности и примеры работы — [в статье на Амперка / Вики](http://wiki.amperka.ru/продукты:troyka-gps-glonass)